# V7-RC-002 executable kinematic test model
# Model-level only; no crash/force law is implied.
import numpy as np
N=181
t=np.linspace(0.0,1.0,N)  # normalized test clock, not physical crash time
q1=180.0*t
q2=-10.0+35.0*t
v1=np.gradient(q1,t); a1=np.gradient(v1,t)
v2=np.gradient(q2,t); a2=np.gradient(v2,t)
assert abs(q1[-1]-q1[0]-180.0)<1e-9
assert np.isfinite(v1).all() and np.isfinite(a1).all()
print('DOF=2 MODEL_EXECUTED')
print('ACTUAL_TRAVEL_MM=',q1[-1]-q1[0])
print('SEATBACK_RANGE_DEG=',q2.min(),q2.max())
